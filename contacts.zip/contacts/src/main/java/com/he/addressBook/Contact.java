package com.he.addressBook;

import java.util.ArrayList;
import java.util.List;

public class Contact {

    private String            name;
    private String            organisation;
    private List<PhoneNumber> phoneNumbers;
    private List<Address>     addresses;
    String personname;
    String organisationname;

    public Contact(String name, String organisation) throws Exception {
        // TODO
    }

    public String getName() {
    	if(name.matches("^[a-zA-Z]+$") && name.length()>0 && name.length()<255)
		{
			personname=name;
		}
		else
		{
			return "Invalid person name";
		}
		return personname;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrganisation() {
    	if(organisation.matches("^[a-zA-Z]+$") && organisation.length()<255)
		{
    		organisationname=organisation;
		}
		else
		{
			return "Invalid org name";
		}
		return organisationname;
      
    }

    public void setOrganisation(String organisation) {
        this.organisation = organisation;
    }

    public List<PhoneNumber> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<PhoneNumber> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public List<Address> getAddresses() {
        return addresses;
    }

    public void setAddresses(List<Address> addresses) {
        this.addresses = addresses;
    }

    public void addPhoneNumber(PhoneNumber phoneNumber) {
        if (this.phoneNumbers == null) {
            this.phoneNumbers = new ArrayList<PhoneNumber>();
        }
        this.phoneNumbers.add(phoneNumber);

    }

    public void addAddress(Address address) {
        if (this.addresses == null) {
            this.addresses = new ArrayList<Address>();
        }
        this.addresses.add(address);
    }

}