package com.he.addressBook;

public class Address {

	private String label;
	private String address;
	String labelname;
	
	public Address(String label, String address) throws Exception {
		// TODO
	}
	
	public String getLabel() {
		if(label.matches("^[a-zA-Z]+$") && label.length()>0 && label.length()<255)
		{
			labelname=label;
		}
		else
		{
			return "Invalid label name";
		}
		return labelname;
	}
	
	public void setLabel(String label) {
		
		this.label = label;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return this.address;
	}
}
