package com.he.addressBook;

public class PhoneNumber {
    private String label;
    private String phoneNumber;
    String phone;
    String labelname;
    public PhoneNumber(String label, String phoneNumber) throws Exception {
        // TODO
    }



    public String getPhoneNumber() {
    	if(phoneNumber.matches("\\d{10}"))
    	{
    		phone=phoneNumber;
    	}
    	else 
    	{
    		return "Invalid phone number";
    	}
        return phone;
    }



	public String getLabel() {
		if(label.matches("^[a-zA-Z]+$") && label.length()>0 && label.length()<255)
		{
			labelname=label;
		}
		else
		{
			return "Invalid label name";
		}
		return labelname;
	}

   
}
