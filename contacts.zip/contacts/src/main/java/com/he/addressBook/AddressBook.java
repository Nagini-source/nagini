package com.he.addressBook;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AddressBook {
	
	ArrayList<Contact> arrayOfContacts= new ArrayList<Contact>();

    public AddressBook() {
        //TODO
    }

    public void addContact(Contact contact) {
        //TODO
    	
    	arrayOfContacts.add(contact);
    for(int i=0;i<arrayOfContacts.size();i++)
    {
    	try
    	{
    	if(arrayOfContacts.get(i).getName()!=contact.getName())
    	{
    		arrayOfContacts.add(contact);
    		
    	}
    	}
    	catch(Exception e)
    	{
    		System.out.println("Print exception..." +e.getMessage());
    	}
    	
    	
    }
    	
    	
    }

    public void deleteContact(String name) {
        //TODO
    	try {
    	for (Iterator<Contact> iterator = arrayOfContacts.iterator(); iterator.hasNext();) {
    	    Contact temp = iterator.next();

    	    // Add null checks for proper error handling.

    	    if (temp.getName().equalsIgnoreCase(name)) {
    	      iterator.remove();
    	      return;
    	    }
    	  }
    	}
    	catch(Exception e)
    	{

    	  System.out.println("No contact with first name " + name + " was found.:" +e.getMessage());
    	}
    }

    public void updateContact(String name, Contact contact) {
        //TODO
    	try
    	{
    	if(!name.equals(contact.getName()))
    	{
    		contact.setName(name);
    	}
    	}
    	catch(Exception e)
    	{
    		System.out.println("Name does not exist..."+e.getMessage());
    	}
    }

    public List<Contact> searchByName(String name,Contact contact) {
        //TODO
    	
		try {
			
			if(contact.getName().startsWith(name)|| name.equals(""))
		    	arrayOfContacts.add(contact);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
        return arrayOfContacts;
    }

    public List<Contact> searchByOrganisation(String organisation, Contact contact) {
        //TODO
    	
		try {
			
			if(contact.getOrganisation().startsWith(organisation)|| organisation.equals(""))
		    	arrayOfContacts.add(contact);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
        return arrayOfContacts;
    }

}